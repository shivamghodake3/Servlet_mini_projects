package http_servlet_demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/info")
public class IndexServlet extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			String name=req.getParameter("myname");
			String email=req.getParameter("myemail");
			String phone=req.getParameter("mynumber");
			
			PrintWriter pw=resp.getWriter();
			pw.print("<html><body>");
			pw.print("NAME: "+name+"<br><br>");
			pw.print("EMAIL ID: "+email+"<br><br>");
			pw.print("PHONE NO: "+phone+"<br><br>");
			pw.print("</body></html>");

	}
}
