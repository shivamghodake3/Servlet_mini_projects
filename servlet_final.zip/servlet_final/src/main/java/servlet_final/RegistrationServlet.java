package servlet_final;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/registration")
public class RegistrationServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/servlettask","root","sql123");
			PreparedStatement ps=con.prepareStatement("insert  into user values(?,?,?,?,?,?)");
			
			String name=req.getParameter("myname");
			String email=req.getParameter("myemail");
			String phone=req.getParameter("mynumber");
			String dob=req.getParameter("dob");
			String gender=req.getParameter("gender");
			String address=req.getParameter("address");
			

			ps.setString(1, name);
			ps.setString(2, email);
			ps.setString(3, phone);
			ps.setString(4, dob);
			ps.setString(5, gender);
			ps.setString(6, address);
			int rs=ps.executeUpdate();
			
			if(rs!=0) {
			RequestDispatcher rd=req.getRequestDispatcher("display.html");
			rd.include(req, resp);
			}
			
			else {
				RequestDispatcher rd=req.getRequestDispatcher("registration.html");
				rd.include(req, resp);
			}
			
//			PrintWriter pw=resp.getWriter();
//			pw.print("...YOUR DETAILS ARE SUCCESSFULLY SAVED...");
			
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
